/**
 * Provides classes for Lab 5.
 */
package csi213.lab06;